public class Child {
    public String name;
    public char gender;
    public int age;
}
